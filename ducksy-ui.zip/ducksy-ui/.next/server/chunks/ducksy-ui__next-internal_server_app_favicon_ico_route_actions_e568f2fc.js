module.exports=[65756,(e,o,d)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_favicon_ico_route_actions_e568f2fc.js.map