module.exports=[65071,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_%28auth%29_dashboard_page_actions_ef9bf1bf.js.map