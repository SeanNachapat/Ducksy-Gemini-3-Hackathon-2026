module.exports=[88487,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_init_page_actions_a84ea3d2.js.map