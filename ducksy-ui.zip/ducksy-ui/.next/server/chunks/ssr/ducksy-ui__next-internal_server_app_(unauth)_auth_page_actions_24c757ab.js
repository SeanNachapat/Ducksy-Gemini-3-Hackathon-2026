module.exports=[46089,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_%28unauth%29_auth_page_actions_24c757ab.js.map