module.exports=[57752,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_page_actions_b95c6111.js.map