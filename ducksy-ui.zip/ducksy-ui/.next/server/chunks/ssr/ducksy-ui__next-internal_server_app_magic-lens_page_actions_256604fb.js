module.exports=[94034,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_magic-lens_page_actions_256604fb.js.map