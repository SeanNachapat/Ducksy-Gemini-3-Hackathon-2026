module.exports=[59619,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_%28auth%29_sessions_page_actions_a31784d3.js.map