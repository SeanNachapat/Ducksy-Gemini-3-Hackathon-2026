module.exports=[86074,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_%28auth%29_onRecord_page_actions_bbdf16e0.js.map