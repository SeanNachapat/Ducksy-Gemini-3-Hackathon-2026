module.exports=[40596,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app__not-found_page_actions_314e2db4.js.map