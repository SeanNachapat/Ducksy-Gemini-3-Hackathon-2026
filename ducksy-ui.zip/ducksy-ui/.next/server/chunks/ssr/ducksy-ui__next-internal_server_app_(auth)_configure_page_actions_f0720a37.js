module.exports=[79802,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app_%28auth%29_configure_page_actions_f0720a37.js.map