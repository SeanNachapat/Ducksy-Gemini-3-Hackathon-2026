module.exports=[13776,(a,b,c)=>{}];

//# sourceMappingURL=ducksy-ui__next-internal_server_app__global-error_page_actions_71d5df5e.js.map