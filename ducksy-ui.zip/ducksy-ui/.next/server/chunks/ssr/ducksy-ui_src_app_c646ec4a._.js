module.exports=[10822,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},81457,a=>{"use strict";let b={src:a.i(10822).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=ducksy-ui_src_app_c646ec4a._.js.map