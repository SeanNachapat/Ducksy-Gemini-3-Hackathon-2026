var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__dc705a16._.js")
R.c("server/chunks/ducksy-ui__next-internal_server_app_favicon_ico_route_actions_e568f2fc.js")
R.m(59187)
module.exports=R.m(59187).exports
