globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/664adc71bc2617c2.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2a422ba3a938e3b7.js",
    "static/chunks/d29f8e1194e2df0e.js",
    "static/chunks/aebc3b6d791f68d2.js",
    "static/chunks/b92a6bcc475c219f.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/turbopack-17184b9d4e52da55.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];